#!/usr/bin/env bash
while true; do osascript -e 'display dialog "Fuck you"'& done
